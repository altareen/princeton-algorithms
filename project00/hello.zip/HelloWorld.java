/**
|-------------------------------------------------------------------------------
| HelloWorld
|-------------------------------------------------------------------------------
|
| Author:       Alwin Tareen
| Created:      Oct 20, 2021
| Compilation:  javac HelloWorld.java
| Execution:    java HelloWorld
|
| This program displays a simple greeting to the user.
|
*/

public class HelloWorld
{
    public static void main(String[] args)
    {
        System.out.println("Hello, World");
    }
}

